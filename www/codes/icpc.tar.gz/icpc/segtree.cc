const int N = 100003;
const int LGN = 17;

int h, n, left_most, right_most;

struct node {

  node() {}
  node(int val) {}
  void merge(node& l, node& r) {}
  void split(node& l, node& r) {}
}tree[1<<(LGN + 1)];

void update_single(node& n, int d) {}

const node IDENTITY;

node query(int root, int left_leaf, int right_leaf, const int u, const int v) {
  if(u >= v) return IDENTITY;
  if(u <= left_leaf && right_leaf <= v) 
    return tree[root];
  int mid = (left_leaf + right_leaf) >> 1,
      lc = root<<1, rc = lc | 1;
  tree[root].split(tree[lc], tree[rc]);
  node ret, l, r;
  if(u < mid) l = query(lc, left_leaf, mid, u, v);
  if(v > mid) r = query(rc, mid, right_leaf, u, v);
  ret.merge(l, r);
  return ret;
}

void splitdown(int idx) {
  if(idx > 1) splitdown(idx>>1);
  tree[idx].split(tree[idx<<1], tree[(idx<<1)|1]);
}

void update(int idx, node new_node) {
  idx |= (1<<h);
  splitdown(idx>>1);
  tree[idx] = new_node;
  idx >>= 1;
  while(idx > 0) {
    tree[idx].merge(tree[idx<<1], tree[(idx<<1)|1]);
    idx >>= 1;
  } 
}

void range_update(int root, int left_leaf, int right_leaf, const int u, const int v, int d) {
  if(u >= v) return;
  if(u <= left_leaf && right_leaf <= v) 
    return update_single(tree[root], d);
  int mid = (left_leaf + right_leaf) >> 1,
      lc = root<<1, rc = lc | 1;
  if(u < mid) range_update(lc, left_leaf, mid, u, v, d);
  if(v > mid) range_update(rc, mid, right_leaf, u, v, d);
  tree[root].merge(tree[lc], tree[rc]);
}

// searches for the last place i, such that mrege[0...i] compares less than k
// requires < operator defined
int binary_search(node k) {
  int root = 1;
  node nd;
  while(root < left_most) {
    int lc = root<<1, rc = lc|1;
    tree[root].split(tree[lc], tree[rc]);
    node m;
    m.merge(nd, tree[lc]);
    if(m < k) {
      nd = m;
      root = rc;
    } else {
      root = lc;
    }
  }
  node ret;
  ret.merge(nd, tree[root]);
  if(m<k)return root - left_most;
  else return root - 1 - left_most;
}

void init(int size, int A[]) {
  n = size;
  h = ceil(log2(n));
  left_most = 1<<h, right_most = left_most<<1;
  for(int i = 0; i < n; i++) tree[i|(1<<h)] = (node){A[i]};
  for(int i = left_most - 1; i > 0; i--) tree[i].merge(tree[i<<1], tree[(i<<1)|1]);
}
