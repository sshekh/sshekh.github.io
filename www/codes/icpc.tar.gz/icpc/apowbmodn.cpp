int modpow(int a,int b) {
  int apow = a;
  int ans = 1;
  while(b) {
    if(b & 1) ans = (ans * apow) % MOD;
    apow = (apow * apow) % MOD;
    b >>= 1;
  } 
}
