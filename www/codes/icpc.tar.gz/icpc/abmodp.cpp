int modprod(int a, int b) {
  int aprod = a;
  int ans = 0;
  while(b > 0) {
    if(b & 1) ans = (ans + aprod) % MOD;
    b = b >> 1;
    aprod = (aprod << 1) % MOD;
  }
  return ans;
}
