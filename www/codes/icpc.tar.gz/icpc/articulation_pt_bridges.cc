// algo for articulation points abr bridges
// d[] is the discovered time
// low[v] is the lowest d[] among all the vertices reachable (taking the edges in the same direction as dfs) from subtree rooted at v, 
// vertex 0 is the root, d[] is -1 initially

const int N = 100003;
vector<int> adjlist[N];
int d[N], tm = 0, low[N], par[N], rnk[N];
int n, m;

void dfs(int u, int parent) {
  d[u] = tm++;
  low[u] = d[u];
  for(int v : adjlist[u]) {
    if(v == parent) continue;
    if(d[v] == -1) {
      dfs(v, u);
      low[u] = min(low[u], low[v]);
      if(low[v] == d[v]) {
        // (u, v) is a bridge
      }
      if ((low[v] >= d[u]) || (!u && adjlist[u].size() > 1)) {
        // u is an articulation point
      }
    } else {
      // back edge
      low[u] = min(low[u], d[v]);
    }
  }
  tm++;
}
