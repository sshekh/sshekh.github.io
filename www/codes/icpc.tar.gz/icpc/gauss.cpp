class MixingColors:
 def minColors(self, colors):
    colors = list(colors)
    n = len(colors)
     
    j = 0 #number of top rows to ignore
    for i in range(0, 31):
        # find a row that has 1 in the i-th bit:
        k = j
        while (k < n) and ( (colors[k] & (1<<i)) == 0 ):
            k += 1
        # if at least one of those rows exists:
        if k != n:
            # swap row k and j
            (colors[j], colors[k]) = (colors[k], colors[j])
            # zero this column in the remaining rows (using xor)
            for k in range(j + 1, n):
                if (colors[k] & (1<<i)) != 0:
                    colors[k] = colors[k] ^ colors[j]
            # ignore one more row
            j += 1
    return sum(c > 0 for c in colors ) # sum of non-zero rows