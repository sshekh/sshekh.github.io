int LCP(int, int);	// return the longest commom prefix of substrings starting from x and y, also prints the LCP
void make_array(char* );
int LCPlen(int, int);	// return the length of the longest common prefix
char str[N];		// Find the suffix array of string str
int Sarray[N];	// The suffix array (lexographically ascending order)
int LCParray[N]; 	// LCP array
int P[LGN][N]; 	// P[k][i] stores the position of (substring of str[] of length 2^k starting at i ) in
// the sorted array of all substrings of str of length 2^k
int len, stp;
struct entry {
  int nr[2]; 	// in case of a substring of len 2^k, will store the 'position' of 1st half and 2nd half 
  int p;		
} L[N];		// will store the temporary positions
bool comp(entry a, entry b){
  return a.nr[0] == b.nr[0] ? (a.nr[1] < b.nr[1]) : (a.nr[0] < b.nr[0]);
}
void make_array(char* str) {
  int cnt;
  len = strlen(str);
  for(int i=0; i<len; i++)	// Initialising P for single characters
    P[0][i] = str[i] - 'a';		// in case of small letters str[i] - 'a', 'A' if caps included 			

  for(cnt = 1, stp=1; cnt>>1 < len; stp++, cnt <<= 1) {	// stp gives level of matrix P, 
    // cnt gives the substring size to take
    for(int i=0; i<len; i++) {					// i is the starting point of the substring
      L[i].nr[0] = P[stp-1][i];
      L[i].nr[1] = i + cnt < len ? P[stp-1][i+cnt] : -1; 	// taking into account the length when calculating the end
      // point of string. Also, -1, like '$' will come first in sorting
      L[i].p = i;		// pointer to the substring
    }
    sort(L, L + len, comp);		// ordering the new 2^(k+1) substrings lexographically
    // can be done in linear time using countsort
    for(int i=0; i<len; i++) {
      // equal substrings must be given the same position
      P[stp][L[i].p] = ( (i>0) && (L[i].nr[0] == L[i-1].nr[0]) && (L[i].nr[1] == L[i-1].nr[1]) ) ? P[stp][L[i-1].p] : i;  
    }

  }
}
int LCPlen(int x, int y) {
  /*Given 2 suffixes str_x^k (length 2^k) and str_y^k, using the matrix P, we descend from highest k to 0 till we get str_x^k = str_y^k. Thus a prefix of length 2^k is found.
   * We increase both x and y by 2^k to see of the prefix extends */
  int k=0, ret=0; 
  if(x == y) return len - x;
  for(k= stp-1; k>=0 && x < len && y < len; k--)
    if(P[k][x] == P[k][y])			// prefix of length 2^k found
      x += 1 << k, y += 1<< k, ret += 1 << k;  	// increment x to get the more mathches
  return ret;
}
int LCP(int x, int y) {
  /*Given 2 suffixes str_x^k (length 2^k) and str_y^k, using the matrix P, we descend from highest k to 0 till we get str_x^k = str_y^k. Thus a prefix of length 2^k is found.
   * We increase both x and y by 2^k to see of the prefix extends */
  int k=0, ret=0, i; 
  if(x == y) {
    i=x;
    for(; i<len; i++)
      putchar(str[i]);
    putchar('\n');
    return len - x;
  }
  for(k= stp-1; k>=0 && x < len && y < len; k--)
    if(P[k][x] == P[k][y])	{		// prefix of length 2^k found
      i=x;
      x += 1 << k, y += 1<< k, ret += 1 << k;  	// increment x to get the more mathches
      for(; i<x; i++)
        putchar(str[i]);
    }
  printf("\n");
  return ret;
}
void printSarray() {	
  for(int i=0; i<len; i++)	// will print the rank of substr[i]
  {
    //printf("%d %s\n", P[stp-1][i], str + i);
    Sarray[ P[stp-1][i] ] = i;
  }
  for(int i=0; i<len; i++)	// will print the suffix array
  {
    //printf("%d %s\n", Sarray[i], str + Sarray[i]);
  }
}
void printLCParray() {
  for(int i=1; i<len; i++) {
    LCParray[i] = LCPlen(Sarray[i-1], Sarray[i]);
    cout << LCParray[i] << " ";
  }
  cout << "\n";
}




