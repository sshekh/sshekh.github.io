// W-L algorithm, if from a position you can go to atleast one losing position, then it is a winning position
// else, it is a losing position
boolean isWinning(position pos) {
  moves[] = possible positions to which I can move from the position pos;
  for (all x in moves) 
    if (!isWinning(x)) return true;
  return false; 
}
// Grundy Numbers, for a simple game, grundy number of a position can be thought of as representing the best move 
// that I can take at the position, I take the grundy of the positions to which I can move from the position and then 
// grundy number of my original position is the mex (minimum excluded ..) from the set
int grundyNumber(position pos) {
  moves[] = possible moves that i can take from pos
    set s;
  for x in moves[]
    s.insert(grundyNumber(x))
      // return the smallest non-negative integer not in the set s
      int ret = 0;
  while(s.contains(ret)) ret++;
  return ret
}
// Note: if we are at a position with grundy number a then from that we can move to any position
// with grundy number < a, because a is the minimum one not reachable, this way this subgame 
// can be reduced to a nim pile
//
// From a position with grundy number 0, we can move to only those positions where grundy number 
// is > 0
// For a game that distributes into many games with one move in only one subgame
// calculate the grundy number for each subgame and then XOR ^ them to give grundy number for the original game
// i.e a pile of Nim is equivalent to the subgame if its size is equal to the grundy number of 
// that subgame
// 1. You can move some of the horses >= 1 and move with all chosen ones
// ans - In a losing position iff all horses are in a losing pos in their own chessboard
//
// 2. Player can choose some, but not all of the horses
// ans - In a losing pos iff the grundy number of all positions, where horses are, is same
// proof: use property of a winning pos as well as a losing pos, from all same, one has to go to atleast one diff. From some diff, we can choose one and then make all other horses to to that pos
