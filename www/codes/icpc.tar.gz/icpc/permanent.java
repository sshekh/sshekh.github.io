static int MOD = 100000007;
public static long permanent(int[][] A) {
  int n = A.length;
  long[] dp = new long[1<<n];
  dp[0] = 1;
  for(int i = 0;i < 1<<n;i++){
    for(int j = 0;j < n;j++){
      if((i&(1<<j))==0){
        dp[i|(1<<j)] += dp[i]*A[Integer.bitCount(i)][j];
        dp[i|(1<<j)] %= MOD;
      }
    }
  }
  return dp[(1<<n)-1];
}