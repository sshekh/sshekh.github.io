//   OUTPUT: mr[i] = assignment for row node i, -1 if unassigned
//           mc[j] = assignment for column node j, -1 if unassigned
vector<int> adjlist[N];
int mr[N], mc[N], seen[N], nl, nr;;

bool FindMatch(int i) {
  for (int j = 0; j < adjlist[i].size(); j++) {
    if (!seen[adjlist[i][j]]) {
      seen[adjlist[i][j]] = true;
      if (mc[adjlist[i][j]] < 0 || FindMatch(mc[adjlist[i][j]])) {
        mr[i] = adjlist[i][j];
        mc[adjlist[i][j]] = i;
        return true;
      }
    }
  }
  return false;
}

int BipartiteMatching() {
  memset(mr, -1, sizeof mr);
  memset(mc, -1, sizeof mc);
  int ct = 0;
  for (int i = 0; i < nl; i++) {
    memset(seen, 0, sizeof seen);
    if (FindMatch(i)) ct++;
  }
  return ct;
}

