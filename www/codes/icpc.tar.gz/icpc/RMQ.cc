// $RM[i, j]$ = min(A[k]), $k \in [i, i + 2^j)$
// for storing index as well, just change RM from int to pair<int, int> and line 7 to RM[i][0] = make_pair(A[i], 0)

int RM[N][LGN];		
void make_rmq(const int n, int A[]) {
  for(int i = 0; i < n; i++)
    RM[i][0] = A[i];
  for(int j = 1; (1<<j) <= n; j++)
    for(int i = 0; i + (1<<j) <= n; i++)
      RM[i][j] = min(RM[i][j-1], RM[i + (1 << (j-1))][j-1]);
}
int minq(int i, int j) {		// minima in interval [i, j]
  int k = log2(j + 1 - i);
  return min(RM[i][k], RM[j + 1 - (1<<k)][k]);
}

