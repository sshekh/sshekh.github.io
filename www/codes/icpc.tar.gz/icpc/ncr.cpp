/*
   ${n}\choose{r}$ = ${n}\choose{r-1}$ $* \frac{n-r+1}{r}$
   ${n}\choose{r}$ = ${n - 1}\choose{r - 1}$ $* \frac{n}{k}$ 
   ${n}\choose{r}$ = ${n - 1}\choose{r - 1}$ $+$ ${n - 1}\choose{r}$
*/
LL binom[N][N];
LL nc[N];
void fillncr() {
  binom[1][1] = 1;
  for(int n = 0; n < N; n++) binom[n][0] = 1;
  for(int n = 1; n < N; n++)
    for(int r = 1; r <= n; r++)
      binom[n][r] = binom[n-1][r-1] + binom[n-1][r];
}

void fillnc(int n) {
  int r;
  nc[0] = 1; nc[1] = n;
  for(r = 2; r<=n; r++) nc[r] = (nc[r-1] * (n-r+1)) / r;
}
