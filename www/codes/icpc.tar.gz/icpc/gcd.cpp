// for gcd, use __gcd()
// __gcd(0, x) = x
// gcd(a, b) is the smallest d such that $ax + by = d$, $x, y \in Z$ 

int ext_euclid(int a, int b, int& x, int& y) {
  if(b == 0) {
    x = 1; y = 0;
    return b;
  }
  int y_, d;
  d = ext_euclid(b, a % b);
  y_ = x - (a / b) * y;
  x_ = y; y = y_;
  return d;
}