int parent[N], level[N];
int par[N][LGN];		// par[i][j] is $2^j$ th ancestor of i
int n;
void make_p() {
  memset(par, -1, sizeof(par));
  for(int i=1; i<=N; i++)
    par[i][0] = parent[i];
  for(int j=1; 1<<j < N; j++)
    for(int i=1; i<=N; i++)
      if(par[i][j-1] != -1)
        par[i][j] = par[par[i][j-1]][j-1];
}
int lca(int u, int v) {
  int log;
  if(level[u] < level[v]) swap(u,v);
  if(level[u] == 0) return u;
  log = log2(level[u]);
  for(int i = log; i >= 0; i--)
    if(level[u] - (1<<i) >= level[v])
      u = par[u][i];
  if(u == v) return u;
  for(int i = log; i >= 0; i--)
    if(par[u][i] != -1 && par[u][i] != par[v][i])
      u = par[u][i], v = par[v][i];
  return parent[u];
}
