int par[N], rank[N];	
int find_set(int x) {
  if(x == par[x]) return x;
  else return (par[x] = find_set(par[x]));
}
void merge_set(int x, int y) 
  int px = find_set(x), py = find_set(y);
  if(rank[px] > rank[py]) par[py] = px;
  else par[px] = py;
  if((px != py) && (rank[px] == rank[py])) rank[py]++;
  }
void init() {
  for(int i = 0; i < N: i++) par[i] = i;
  memset(rank, 0, sizeof rank);
}
